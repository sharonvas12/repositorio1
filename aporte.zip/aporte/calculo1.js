// main.js

document.addEventListener('DOMContentLoaded', function () {
    const form = document.querySelector('form');
    form.addEventListener('submit', function (event) {
        event.preventDefault();
        calculateSale();
    });

    function calculateSale() {
        // Obtener valores del formulario
        const bookName = document.getElementById('nombreLibro').value;
        const bookCode = document.getElementById('codigo').value;
        const category = document.getElementById('categoria').value;
        const price = parseFloat(document.getElementById('precio').value);
        const quantity = parseInt(document.getElementById('cantidad').value);
        const customer = document.getElementById('cliente').value;
        const customerAge = parseInt(document.getElementById('edadCliente').value) || 0;
        const saleDate = document.getElementById('fechaVenta').value;

        // Calcular descuentos y recargos
        let discount = 0;
        let surcharge = 0;

        // Descuento por promoción
        const currentDate = new Date(saleDate);
        if (currentDate.getDay() === 5) {
            discount += 0.3; // Viernes negro
        }

        // Descuento para la tercera edad
        if (customerAge >= 65) {
            discount += 0.08;
        }

        // Descuento por valor de compra
        const totalAmount = price * quantity;
        if (totalAmount > 100) {
            discount += 0.03;
        }

        // Recargo por compras superiores al 500%
        if (totalAmount > 500) {
            surcharge += 0.08;
        }

        // Calcular total a pagar
        const subtotal = totalAmount * (1 - discount + surcharge);
        const iva = subtotal * 0.12;
        const totalToPay = subtotal + iva;

        // Mostrar resultados
        document.getElementById('iva').value = iva.toFixed(2);
        document.getElementById('totalPagar').value = totalToPay.toFixed(2);

        // Agregar la venta a la tabla de ventas realizadas
        addSaleToTable(bookName, bookCode, category, price, quantity, customer, customerAge, saleDate, iva, totalToPay);
    }

    function addSaleToTable(bookName, bookCode, category, price, quantity, customer, customerAge, saleDate, iva, totalToPay) {
        const salesTableBody = document.querySelector('table tbody');

        const newRow = document.createElement('tr');
        newRow.innerHTML = `
            <td>${bookName}</td>
            <td>${bookCode}</td>
            <td>${category}</td>
            <td>${price.toFixed(2)}</td>
            <td>${quantity}</td>
            <td>${customer}</td>
            <td>${customerAge}</td>
            <td>${saleDate}</td>
            <td>${iva.toFixed(2)}</td>
            <td>${totalToPay.toFixed(2)}</td>
        `;

        salesTableBody.appendChild(newRow);
    }
});
